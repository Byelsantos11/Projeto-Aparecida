from django.apps import AppConfig


class AppAparecidaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'app_aparecida'
